def absFunction():
    number1 = 100
    number2 = 500
    #Compare teh two objects x and y and return an integer according to the outcome. The return value is negative if x < y, zero if x == y and strictly positive if x > y.
    coper = cmp(number1,number2)
    print(coper)
    #Return teh absolute value of a number. Teh argument may be a plain or long integer or a floating point number. If teh argument is a complex number, its magnitude is returned
   # ab = abs(number)
   # print(ab)

absFunction()
